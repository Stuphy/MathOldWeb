$(document).ready(function() {

    $(".main_head").css("min-height", $(window).height());

});